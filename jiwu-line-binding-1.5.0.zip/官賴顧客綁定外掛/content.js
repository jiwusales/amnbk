(()=>{
  if(document.getElementById('jiwu-line-bind-root'))return;
  const host=document.createElement('div');host.id='jiwu-line-bind-root';document.documentElement.append(host);
  const shadow=host.attachShadow({mode:'closed'});
  shadow.innerHTML=`<style>:host{all:initial}*{box-sizing:border-box}button,input{font:14px system-ui}button{cursor:pointer;border:0;border-radius:8px;padding:9px 12px;background:#06a85b;color:white}button:disabled{opacity:.5;cursor:wait}.wrap{position:fixed;right:20px;bottom:24px;z-index:2147483647;font:14px system-ui;color:#26332c;width:320px;max-width:calc(100vw - 16px)}.panel{background:white;border:1px solid #ddd;border-radius:12px;box-shadow:0 8px 30px #0003;padding:16px;margin-bottom:8px;max-height:calc(100vh - 80px);overflow:auto}.panel[hidden]{display:none}h3{margin:0 0 10px;font-size:17px;cursor:move;touch-action:none}p{margin:8px 0;line-height:1.5}input{width:100%;padding:9px;margin:5px 0;border:1px solid #ccc;border-radius:6px}.actions,.dock{display:flex;gap:8px}.dock{justify-content:flex-end}.light{background:#edf1ed;color:#26332c}.status{white-space:pre-wrap;color:#43584b}.error{color:#bd3030}.meta{word-break:break-all;color:#777;font-size:11px}.handle{cursor:move;touch-action:none;background:#e4ece6;color:#36513d;user-select:none}</style><div class="wrap"><div class="panel" hidden><h3>儲存官賴顧客 ⠿</h3><div class="body"></div><p class="status" role="status"></p><div class="actions" style="margin-top:12px"><button class="light close">關閉</button><button class="light retryQueue" hidden>重試儲存</button></div></div><div class="dock"><button class="handle" title="拖曳移動" aria-label="拖曳移動">⠿</button><button class="toggle">📥 儲存顧客</button></div></div>`;
  const wrap=shadow.querySelector('.wrap'),panel=shadow.querySelector('.panel'),body=shadow.querySelector('.body'),status=shadow.querySelector('.status'),toggle=shadow.querySelector('.toggle');
  let authenticated=false,generation=0,lastURL=location.href,lastName='',blockedName='',stableKey='',stableAt=0,attempt='',queueStatusBusy=false;
  const currentURL=()=>location.origin+location.pathname;
  const valid=()=>/^https:\/\/chat\.line\.biz\/U[0-9a-f]{32}\/chat\/U[0-9a-f]{32}\/?$/i.test(currentURL());
  const message=(text,error=false)=>{status.textContent=text;status.className='status'+(error?' error':'');};
  const send=async data=>{const response=await chrome.runtime.sendMessage(data);if(!response||response.ok===false)throw new Error(response?.error||'外掛連線中斷，請重新整理');return response;};
  const notifications=document.createElement('div');notifications.style.cssText='position:fixed;right:20px;top:20px;z-index:2147483647;display:flex;flex-direction:column;gap:8px;pointer-events:none';notifications.setAttribute('role','status');notifications.setAttribute('aria-live','polite');shadow.append(notifications);
  chrome.runtime.onMessage.addListener(message=>{
    if(message.type!=='customerSaved')return;
    const toast=document.createElement('div');toast.textContent='✓ '+message.customer+(message.updated?' 名稱已更新':' 登記完成');toast.style.cssText='background:#087d47;color:white;padding:12px 18px;border-radius:10px;box-shadow:0 4px 16px #0003;font:14px system-ui;max-width:320px;overflow-wrap:anywhere';notifications.append(toast);setTimeout(()=>toast.remove(),2000);
  });
  function clampPosition(left,top){const r=wrap.getBoundingClientRect();wrap.style.left=Math.max(8,Math.min(left,innerWidth-r.width-8))+'px';wrap.style.top=Math.max(8,Math.min(top,innerHeight-r.height-8))+'px';wrap.style.right='auto';wrap.style.bottom='auto';}
  for(const handle of [shadow.querySelector('.handle'),shadow.querySelector('h3')]){
    handle.onpointerdown=event=>{if(event.button!==0)return;event.preventDefault();const r=wrap.getBoundingClientRect(),dx=event.clientX-r.left,dy=event.clientY-r.top;handle.setPointerCapture(event.pointerId);
      handle.onpointermove=e=>clampPosition(e.clientX-dx,e.clientY-dy);
      handle.onpointerup=()=>{handle.onpointermove=null;const position=wrap.getBoundingClientRect();chrome.storage.local.set({position:{left:position.left,top:position.top}});};
      handle.onpointercancel=()=>{handle.onpointermove=null;};
    };
  }
  window.addEventListener('resize',()=>{const r=wrap.getBoundingClientRect();clampPosition(r.left,r.top);});
  chrome.storage.local.get('position').then(saved=>{if(saved.position)clampPosition(saved.position.left,saved.position.top);});
  chrome.storage.local.remove('shortcut');
  function readChatName(){
    const title=new Set(),profile=new Set(),visited=new Set();
    const walker=document.createTreeWalker(document.body,NodeFilter.SHOW_TEXT);
    const visibleName=element=>{
      const text=part=>{
        if(part.nodeType===3)return part.textContent;
        if(part.nodeType!==1||part.matches('script,style,button,svg'))return '';
        if(part.tagName==='IMG')return part.alt||'';
        return [...part.childNodes].map(text).join('');
      };
      return text(element).replace(/\s+/g,' ').trim();
    };
    let node;
    while((node=walker.nextNode())){
      let parent=node.parentElement;
      if(!parent||parent.closest('script,style,input,textarea,button'))continue;
      // 姓名可能由文字、emoji、span 分段組成，合併小範圍父元素。
      for(let depth=0;parent&&depth<3;depth++,parent=parent.parentElement){
        if(visited.has(parent))continue;visited.add(parent);
        const r=parent.getBoundingClientRect();
        if(!r.width||!r.height||r.top<0||r.top>Math.min(220,innerHeight*.3)||r.height>65)continue;
        if(getComputedStyle(parent).visibility==='hidden'||getComputedStyle(parent).display==='none')continue;
        const name=visibleName(parent);if(!name||name.length>100)continue;
        // 聊天列表可收合，因此標題可能從最左側開始。
        if(r.left>=0&&r.right<innerWidth*.8)title.add(name);
        if(r.left>innerWidth*.8)profile.add(name);
      }
    }
    const names=[...title].filter(name=>profile.has(name)).sort((a,b)=>b.length-a.length);
    if(!names.length)return '';
    // 優先完整名稱；不接受兩個互不包含的候選文字。
    return names.every(name=>names[0].includes(name))?names[0]:'';
  }

  function login(){
    body.innerHTML='<p>外掛會沿用吉物後台的登入狀態，不用另外輸入密碼。請先在這個 Chrome 開啟並登入後台。</p><button class="openAdmin">開啟吉物後台</button>';
    body.querySelector('.openAdmin').onclick=async()=>{try{await send({type:'openAdmin'});}catch(e){message(e.message,true);}};
  }
  let checkingSession=false;
  setInterval(async()=>{if(authenticated||checkingSession)return;checkingSession=true;try{await send({type:'check'});authenticated=true;attempt='';if(!panel.hidden)render();message('已連接吉物後台');}catch(_){}finally{checkingSession=false;}},3000);
  function render(){
    generation++;body.replaceChildren();
    if(!authenticated){login();return;}
    if(!valid()){message('請先開啟一位客人的聊天。');return;}
    body.innerHTML='<p>把目前官賴客人的姓名、UID 存到顧客分頁。訂單姓名會在後台點 💬 時對應。</p><input class="name" aria-label="官賴顧客名稱" placeholder="官賴顧客名稱"><p class="meta"></p><button class="save">儲存目前客人</button>';
    body.querySelector('.name').value=readChatName();body.querySelector('.meta').textContent='UID：'+currentURL().split('/chat/')[1];
    const url=currentURL();body.querySelector('.save').onclick=()=>capture(body.querySelector('.name').value.trim(),url,false);
    if(!readChatName())message('未能讀取姓名，請填入目前客人的官賴名稱。');
  }
  async function capture(name,url,automatic){
    if(!authenticated||!name)return;if(url!==currentURL())return;
    const key=url+'|'+name;if(automatic&&attempt===key)return;
    if(automatic&&readChatName()!==name)return;
    attempt=key;message('加入儲存佇列…');
    try{const result=await send({type:'capture',customer:name,url});if(url!==currentURL())return;toggle.textContent='⏳ 待儲存 '+result.count+' 位';message('已排入：'+name+'，可以點下一位客人。');}
    catch(e){if(url===currentURL()){attempt='';message(e.message,true);if(/登入/.test(e.message)){authenticated=false;login();}}}
  }
  shadow.querySelector('.retryQueue').onclick=async()=>{try{await send({type:'retryQueue'});message('繼續儲存中…');}catch(e){message(e.message,true);}};
  setInterval(async()=>{
    if(!authenticated||queueStatusBusy)return;queueStatusBusy=true;
    try{const state=await send({type:'queueStatus'});shadow.querySelector('.retryQueue').hidden=!state.error;
      if(state.error){toggle.textContent='⚠ 待儲存 '+state.count+' 位';message(state.error,true);}
      else if(state.count){toggle.textContent='⏳ 待儲存 '+state.count+' 位';}
      else if(state.last?.url===currentURL()){toggle.textContent='✓ 已儲存 '+state.last.customer;}
    }catch(_){}finally{queueStatusBusy=false;}
  },1500);
  function togglePanel(){panel.hidden=!panel.hidden;if(!panel.hidden){render();const r=wrap.getBoundingClientRect();clampPosition(r.left,r.top);}}
  toggle.onclick=togglePanel;shadow.querySelector('.close').onclick=()=>{panel.hidden=true;};
  setInterval(()=>{
    if(lastURL!==location.href){blockedName=lastName;lastURL=location.href;stableKey='';attempt='';toggle.textContent='📥 儲存顧客';if(!panel.hidden)render();}
    if(!valid())return;
    const name=readChatName(),key=currentURL()+'|'+name;
    const input=body.querySelector('.name');if(name&&input&&!input.value.trim())input.value=name;
    if(key!==stableKey){stableKey=key;stableAt=Date.now();}
    if(name&&name!==blockedName&&Date.now()-stableAt>200){lastName=name;capture(name,currentURL(),true);}
  },100);
  send({type:'check'}).then(()=>{authenticated=true;attempt='';}).catch(()=>{});
})();
