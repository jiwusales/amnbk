/* Prepare a shipping notice in the selected chat. Never send it. */
(()=>{
 'use strict';
 const target=location.origin+location.pathname;
 if(!/^https:\/\/chat\.line\.biz\/U[0-9a-f]{32}\/chat\/U[0-9a-f]{32}\/?$/i.test(target))return;
 const key='jiwu_line_shipping_draft_v1';
 let pending=null;
 try{
  if(location.hash.startsWith('#jiwuDraft=')){
   pending={target,text:decodeURIComponent(location.hash.slice(11)),expires:Date.now()+15*60*1000};
   if(!pending.text||pending.text.length>30000)return;
   sessionStorage.setItem(key,JSON.stringify(pending));
   history.replaceState(history.state,'',location.pathname+location.search);
  }else pending=JSON.parse(sessionStorage.getItem(key)||'null');
 }catch(_){return;}
 if(!pending||pending.target!==target||pending.expires<Date.now())return;
 const current=()=>location.origin+location.pathname===target;
 function editor(){
  const fields=[...document.querySelectorAll('textarea,[contenteditable="true"]')].filter(el=>!el.closest('#jiwu-line-bind-root,#jiwu-line-shipping-draft')&&el.getClientRects().length&&!el.disabled&&!el.readOnly);
  const messages=fields.filter(el=>/訊息|message|メッセージ|消息/i.test([el.getAttribute('placeholder'),el.getAttribute('aria-label'),el.getAttribute('data-placeholder')].join(' ')));
  return messages.length===1?messages[0]:fields.length===1?fields[0]:null;
 }
 function value(el){return el.tagName==='TEXTAREA'?el.value:el.innerText;}
 function fill(el,text){
  if(!current())return false;
  el.focus();
  if(el.tagName==='TEXTAREA'){
   Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype,'value').set.call(el,text);
   el.dispatchEvent(new Event('input',{bubbles:true}));
  }else{
   const selection=getSelection(),range=document.createRange();range.selectNodeContents(el);selection.removeAllRanges();selection.addRange(range);
   const html=text.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/\n/g,'<br>');
   if(!document.execCommand('insertHTML',false,html))return false;
  }
  if(value(el).replace(/\r/g,'').trim()!==text.trim())return false;
  sessionStorage.removeItem(key);return true;
 }
 let panel,done=false;
 function showPanel(message){
  if(panel){panel.querySelector('[role="status"]').textContent=message;return;}
  panel=document.createElement('div');panel.id='jiwu-line-shipping-draft';
  panel.style.cssText='position:fixed;right:20px;top:20px;z-index:2147483647;background:white;color:#555;border:1px solid #ddd;border-radius:12px;padding:14px;box-shadow:0 4px 20px #0003;width:340px;max-width:calc(100vw - 40px);font:14px system-ui;box-sizing:border-box';
  const status=document.createElement('p');status.setAttribute('role','status');status.textContent=message;
  const text=document.createElement('textarea');text.value=pending.text;text.readOnly=true;text.style.cssText='width:100%;height:180px;box-sizing:border-box;font:13px system-ui';text.setAttribute('aria-label','出貨通知文字');
  const copy=document.createElement('button');copy.textContent='複製通知';copy.onclick=async()=>{try{await navigator.clipboard.writeText(pending.text);status.textContent='已複製，請貼上並確認後送出';}catch(_){text.focus();text.select();status.textContent='請複製已選取的通知文字';}};
  const append=document.createElement('button');append.textContent='帶入輸入框';append.onclick=()=>{const el=editor();if(!el||!current()){status.textContent='請先開啟這位客人的文字輸入框';return;}if(fill(el,pending.text)){done=true;status.textContent='已帶入通知，請確認後送出';}};
  const close=document.createElement('button');close.textContent='關閉';close.onclick=()=>{done=true;sessionStorage.removeItem(key);panel.remove();};
  [copy,append,close].forEach(button=>{button.type='button';button.style.cssText='margin:8px 6px 0 0;padding:6px 9px;cursor:pointer';});
  panel.append(status,text,copy,append,close);document.body.append(panel);
 }
 const started=Date.now();
 function tryFill(){
  if(done||!document.body)return;
  if(!current()){done=true;panel?.remove();return;}
  const el=editor();
  if(el){
   if(fill(el,pending.text)){done=true;showPanel('已帶入出貨通知，請確認後送出。');return;}
  }
  if(Date.now()-started>20000){done=true;showPanel('通知已準備好；請開啟文字輸入框後點「帶入輸入框」，或複製貼上。');}
 }
 const timer=setInterval(()=>{tryFill();if(done)clearInterval(timer);},400);
})();
