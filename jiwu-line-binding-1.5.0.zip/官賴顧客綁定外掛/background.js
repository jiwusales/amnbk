const API_URL="https://script.google.com/macros/s/AKfycbydO3PzBMzM-kkYqhq-sJOsp6eJOKhpR2PJYV9_NvyfzIBMn6n4il8Mz4_iQj2EWgg5/exec";
async function request(action,params={},tokenOverride){
  const stored=await chrome.storage.session.get('token');
  const token=tokenOverride===undefined?stored.token:tokenOverride;
  const response=await fetch(API_URL,{method:'POST',headers:{'Content-Type':'text/plain;charset=utf-8'},body:JSON.stringify({action,...params,token:token||''}),signal:AbortSignal.timeout(25000)});
  if(!response.ok)throw new Error('後台連線失敗：'+response.status);
  let data;try{data=await response.json();}catch(_){throw new Error('後台回應不正確，請確認 Apps Script 已部署');}
  if(data.ok===false)throw new Error(data.error||'後台操作失敗');
  return data;
}
let queueMutation=Promise.resolve(),draining=false;
function mutateQueue(fn){const next=queueMutation.then(async()=>{const stored=await chrome.storage.local.get('customerQueue');const state=stored.customerQueue||{items:[],error:'',last:null};const result=await fn(state);await chrome.storage.local.set({customerQueue:state});return result;});queueMutation=next.catch(()=>{});return next;}
async function drainQueue(){
  if(draining)return;draining=true;
  try{
    const {token}=await chrome.storage.session.get('token');if(!token)return;
    while(true){
      const item=await mutateQueue(state=>state.error?null:state.items[0]);if(!item)return;
      try{
        const result=await request('saveLineChatContact',{customer:item.customer,url:item.url});
        await mutateQueue(state=>{if(state.items[0]?.key===item.key)state.items.shift();state.last={key:item.key,customer:item.customer,url:item.url};});
        if(item.tabId){try{await chrome.tabs.sendMessage(item.tabId,{type:'customerSaved',customer:item.customer,url:item.url,updated:!!result.updated});}catch(_){}}
      }catch(error){await mutateQueue(state=>{state.error=error.name==='TimeoutError'?'連線逾時，待儲存資料已保留，請點重試':error.message;});return;}
    }
  }finally{draining=false;}
}
chrome.alarms.create('customerQueueResume',{periodInMinutes:1});
chrome.alarms.onAlarm.addListener(alarm=>{if(alarm.name==='customerQueueResume')drainQueue();});
chrome.runtime.onMessage.addListener((message,sender,reply)=>{
  if(!sender.url)return false;
  const sourceURL=new URL(sender.url);
  const isAdmin=sourceURL.origin==='https://jiwusales.github.io'&&sourceURL.pathname.startsWith('/amnbk/');
  if(isAdmin){
    if(message.type!=='adminSession')return false;
    (async()=>{const token=String(message.token||'');const stored=await chrome.storage.session.get('token');
      if(!token){await chrome.storage.session.remove('token');return {ok:true};}
      if(token!==stored.token){await request('authCheck',{},token);await chrome.storage.session.set({token});await mutateQueue(state=>{state.error='';});drainQueue();}
      return {ok:true};
    })().then(reply).catch(()=>reply({ok:false}));return true;
  }
  if(sourceURL.origin!=='https://chat.line.biz')return false;
  (async()=>{
    if(message.type==='openAdmin'){await chrome.tabs.create({url:'https://jiwusales.github.io/amnbk/'});return {ok:true};}
    if(message.type==='check'){const {token}=await chrome.storage.session.get('token');if(!token)throw new Error('請先登入吉物後台');return request('authCheck');}
    if(message.type==='customers'){const {token}=await chrome.storage.session.get('token');if(!token)throw new Error('請先登入吉物後台');return request('lineChatCustomers');}
    if(message.type==='capture'){
      const requested=new URL(String(message.url||'')),source=new URL(sender.url);
      const current=requested.origin+requested.pathname,customer=String(message.customer||'').trim();
      // 接受已在內容腳本擷取的對話快照，之後切換聊天不會取消前一筆。
      if(requested.origin!==source.origin||requested.pathname.split('/')[1]!==source.pathname.split('/')[1]||!/^https:\/\/chat\.line\.biz\/U[0-9a-f]{32}\/chat\/U[0-9a-f]{32}\/?$/i.test(current)||!customer||customer.length>100)throw new Error('顧客資料格式不正確');
      const {token}=await chrome.storage.session.get('token');if(!token)throw new Error('請先登入吉物後台');
      const key=current.replace(/\/$/,'')+'|'+customer;
      const result=await mutateQueue(state=>{if(!state.items.some(item=>item.key===key)&&state.last?.key!==key)state.items.push({key,customer,url:current,tabId:sender.tab?.id});return {ok:true,queued:true,count:state.items.length,error:state.error};});
      drainQueue();return result;
    }
    if(message.type==='queueStatus'){const result=await mutateQueue(state=>({ok:true,count:state.items.length,error:state.error,last:state.last}));drainQueue();return result;}
    if(message.type==='retryQueue'){await mutateQueue(state=>{state.error='';});drainQueue();return {ok:true};}
    if(message.type==='logout'){await chrome.storage.session.remove('token');return {ok:true};}
    throw new Error('不支援的操作');
  })().then(reply).catch(error=>reply({ok:false,error:error.name==='TimeoutError'?'後台連線逾時，請確認網路及 Apps Script 部署後重試':error.message}));
  return true;
});
