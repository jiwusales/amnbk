(()=>{
  if(location.origin!=='https://jiwusales.github.io'||!location.pathname.startsWith('/amnbk/'))return;
  let previous=null,pending=false;
  async function sync(){
    if(pending)return;
    const token=localStorage.getItem('jiwu_admin_auth_token_trusted')||sessionStorage.getItem('jiwu_admin_auth_token')||'';
    if(token===previous||(!token&&previous===null))return;
    pending=true;
    try{const result=await chrome.runtime.sendMessage({type:'adminSession',token});if(result?.ok)previous=token;}catch(_){}finally{pending=false;}
  }
  sync();setInterval(sync,1000);window.addEventListener('storage',sync);
})();
